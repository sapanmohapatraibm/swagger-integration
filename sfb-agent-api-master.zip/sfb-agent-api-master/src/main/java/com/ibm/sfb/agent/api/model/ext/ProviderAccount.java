package com.ibm.sfb.agent.api.model.ext;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown=true)
public class ProviderAccount {

	private String href;
	private String cmProviderAccountName;
	private String cmProviderAccountId;
    private String apiPassword;
    private String apiUsername;
    private String billingRef;

}
