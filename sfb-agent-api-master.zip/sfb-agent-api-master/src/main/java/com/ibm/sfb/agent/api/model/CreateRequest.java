package com.ibm.sfb.agent.api.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ibm.sfb.agent.api.model.ext.AssetDetails;
import com.ibm.sfb.agent.api.model.ext.ProviderAccount;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class CreateRequest {

	private String assetName;
	private String service;
	private String location;
	private Map<String, String> serviceSpecificConfigurations;
	private ProviderAccount providerAccount;	
	private AssetDetails assetDetails;
	
}
