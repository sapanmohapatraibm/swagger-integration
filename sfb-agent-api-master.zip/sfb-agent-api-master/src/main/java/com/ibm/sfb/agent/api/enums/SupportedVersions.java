package com.ibm.sfb.agent.api.enums;

public enum SupportedVersions {
	
	v2016_01_31("2016-01-31"),
	v2016_04_30("2016-04-30"),
	v2016_07_31("2016-07-31"),
	v2016_10_31("2016-10-31"),
	v2016_11_30("2016-11-30");

	private String version;

	private SupportedVersions(String version) {
		this.version = version;
	}

	public String getVersion() {
		return version;
	}

}
