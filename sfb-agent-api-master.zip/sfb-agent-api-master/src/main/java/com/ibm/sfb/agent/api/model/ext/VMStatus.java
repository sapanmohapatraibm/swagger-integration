package com.ibm.sfb.agent.api.model.ext;

public enum VMStatus {
	ON, 
	OFF, 
	TERMINATED,
	UNRECOGNIZED;
}
