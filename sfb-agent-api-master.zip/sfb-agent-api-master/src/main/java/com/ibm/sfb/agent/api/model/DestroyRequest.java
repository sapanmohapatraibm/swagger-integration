package com.ibm.sfb.agent.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class DestroyRequest {
	
	public String assetName;
	public String service;
//	public String operationType;
//	public String location;
//	public String headers;
//	public Map<String,String> agentCustomData;
	public String providerAssetId;
//	public String submittedBy;
//	public String createTime;
//	public String updatedTime;
//	public String createdBy;
//	public String updatedBy;
//	public String type;
//	public String orderId;
//	public Map<String,String> provider;
//	public Map<String,String> customer;
//	public Map<String,String> providerAccount;
//	public Map<String,String> assetDetails;
//	public String cmApplication;
//	public String networks;
//	public HashMap<String,String> serviceSpecificConfigurations;
	
}
