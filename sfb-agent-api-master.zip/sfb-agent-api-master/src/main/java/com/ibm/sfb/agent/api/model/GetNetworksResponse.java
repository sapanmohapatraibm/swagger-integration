package com.ibm.sfb.agent.api.model;

import java.util.List;

import com.ibm.sfb.agent.api.model.ext.Network;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class GetNetworksResponse {
	
	private List<Network> networks;

}