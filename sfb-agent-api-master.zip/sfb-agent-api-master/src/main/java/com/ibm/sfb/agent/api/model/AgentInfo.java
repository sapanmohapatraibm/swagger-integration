package com.ibm.sfb.agent.api.model;

import java.util.List;

import com.ibm.sfb.agent.api.model.ext.Action;
import com.ibm.sfb.agent.api.model.ext.SystemConnectivity;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class AgentInfo {

	private String name;
	private String description;
	private List<Action> actions;
	private String delegationType;
	private String supportedVersion;
    private SystemConnectivity systemConnectivity;

}
