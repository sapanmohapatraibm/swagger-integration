package com.ibm.sfb.agent.api.model.ext;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class Records {
	
	private int size;
	
}
