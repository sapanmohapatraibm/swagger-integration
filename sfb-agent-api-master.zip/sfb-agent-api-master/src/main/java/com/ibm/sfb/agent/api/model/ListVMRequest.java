package com.ibm.sfb.agent.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ibm.sfb.agent.api.model.ext.ProviderAccount;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown=true)
public class ListVMRequest {

	private String location;
	private ProviderAccount providerAccount;
	
}
