package com.ibm.sfb.agent.api.enums;

public enum StatusTypeEnum
{
    NEW, COMPLETE, IN_PROGRESS, FAILED;
}
