package com.ibm.sfb.agent.api;


import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.sfb.agent.api.model.AgentInfo;
import com.ibm.sfb.agent.api.model.CreateRequest;
import com.ibm.sfb.agent.api.model.CreateResponse;
import com.ibm.sfb.agent.api.model.GetNetworksRequest;
import com.ibm.sfb.agent.api.model.GetNetworksResponse;
import com.ibm.sfb.agent.api.model.ListVMRequest;
import com.ibm.sfb.agent.api.model.ListVMResponse;
import com.ibm.sfb.agent.api.model.LoadTemplatesRequest;
import com.ibm.sfb.agent.api.model.LoadTemplatesResponse;
import com.ibm.sfb.agent.api.model.ServiceDetailsRequest;
import com.ibm.sfb.agent.api.model.ServiceDetailsResponse;
import com.ibm.sfb.agent.api.model.StatusRequest;
import com.ibm.sfb.agent.api.model.StatusResponse;
import com.ibm.sfb.agent.api.model.TestConnectionRequest;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

public abstract class BaseAgent {
	
	private static final Logger LOGGER = Logger.getLogger(BaseAgent.class);

	@RequestMapping(value="/info",method = RequestMethod.GET)

	public final AgentInfo getInfo() throws Exception {
		return info();
	}
	
	protected AgentInfo info() throws Exception {
		throw new Exception("/info endpoint is not supported");
	}

	@ApiOperation(value = "Create a service agent",response = Iterable.class)
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successfully created"),
            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
    }
    )
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public final CreateResponse create(@RequestParam("data") String data, @RequestParam("file") MultipartFile[] submissions) throws Exception {
		LOGGER.info("data : \n" + data);
		
		ObjectMapper mapper = new ObjectMapper();
		CreateRequest req = mapper.readValue(data, CreateRequest.class);
		return create(req, submissions);
	}
	
	protected CreateResponse create(CreateRequest req, MultipartFile[] submissions) throws Exception {
		throw new Exception("/create endpoint is not supported");
	}
	@ApiOperation(value = "Load the status for a particular job")
	@RequestMapping(value = "/status/{jobId}", method = RequestMethod.POST)
	public final StatusResponse status(@PathVariable(value = "jobId") String jobId, @RequestBody String request) throws Exception {
		LOGGER.info("request : \n" + request);
		
		ObjectMapper mapper = new ObjectMapper();
		StatusRequest req = mapper.readValue(request, StatusRequest.class);
		return status(jobId, req);
	}
	
	protected StatusResponse status(String jobId, StatusRequest req) throws Exception {
		throw new Exception("/status endpoint is not supported");
	}
	
	@ApiOperation(value = "Load the service details")
	 @ApiResponses(value = {
	            @ApiResponse(code = 201, message = "Successfully created"),
	            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
	            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
	            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
	    }
	    )
	@RequestMapping(value = "/serviceDetails", method = RequestMethod.POST)
	public final ServiceDetailsResponse serviceDetails(@RequestBody String request) throws Exception {
		LOGGER.info("request : \n" + request);
		
		ObjectMapper mapper = new ObjectMapper();
		ServiceDetailsRequest req = mapper.readValue(request, ServiceDetailsRequest.class);
		return serviceDetails(req);
	}
	
	protected ServiceDetailsResponse serviceDetails(ServiceDetailsRequest req) throws Exception {
		throw new Exception("/serviceDetails endpoint is not supported");
	}

//	@RequestMapping(value = "/destroy", method = RequestMethod.POST)
//	public DestroyResponse destroy(@RequestBody DestroyRequest request) throws Exception {
//		throw new Exception("/destroy endpoint is not supported");
//	}
	@ApiOperation(value = "Test the connection details")
	/* @ApiResponses(value = {
	            @ApiResponse(code = 200, message = "Successfully created"),
	            @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
	            @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
	            @ApiResponse(code = 404, message = "The resource you were trying to reach is not found")
	    }
	    )*/
	@RequestMapping(value = "/testConnection", method = RequestMethod.POST)
	public final boolean testConnection(@RequestBody String request) throws Exception {
		LOGGER.info("request : \n" + request);
		
		ObjectMapper mapper = new ObjectMapper();
		TestConnectionRequest req = mapper.readValue(request, TestConnectionRequest.class);
		return testConnection(req);
	}
	
	protected boolean testConnection(TestConnectionRequest request) throws Exception {
		throw new Exception("/testConnection endpoint is not supported");
	}
	@ApiOperation(value = "Load the template details")
	@RequestMapping(value = "/loadTemplates", method = RequestMethod.POST)
	public final LoadTemplatesResponse loadTemplates(@RequestBody String request) throws Exception {
		LOGGER.info("request : \n" + request);
		
		ObjectMapper mapper = new ObjectMapper();
		LoadTemplatesRequest req = mapper.readValue(request, LoadTemplatesRequest.class);
		return loadTemplates(req);
	}
	
	protected LoadTemplatesResponse loadTemplates(LoadTemplatesRequest req) throws Exception {
		throw new Exception("/loadTemplates endpoint is not supported");
	}
	
	@RequestMapping(value = "/networks", method = RequestMethod.POST)
	public final GetNetworksResponse networks(@RequestBody String request) throws Exception {
		LOGGER.info("request : \n" + request);
		
		ObjectMapper mapper = new ObjectMapper();
		GetNetworksRequest req = mapper.readValue(request, GetNetworksRequest.class);
		return networks(req);
	}
	
	protected GetNetworksResponse networks(GetNetworksRequest req) throws Exception {
		throw new Exception("/networks endpoint is not supported");
	}
	
	@RequestMapping(value = "/list", method = RequestMethod.POST)
	public final ListVMResponse listVMs(@RequestBody String request) throws Exception {
		LOGGER.info("request : \n" + request);
		
		ObjectMapper mapper = new ObjectMapper();
		ListVMRequest req = mapper.readValue(request, ListVMRequest.class);
		return listVMs(req);
	}
	
	protected ListVMResponse listVMs(ListVMRequest request) throws Exception {
		throw new Exception("/list endpoint is not supported");
	}
	
}
