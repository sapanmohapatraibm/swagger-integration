package com.ibm.sfb.agent.api.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ibm.sfb.agent.api.model.ext.AssetDetails;
import com.ibm.sfb.agent.api.model.ext.ProviderAccount;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatusRequest {

	public String assetName;
	public String service;
	public String operationType;
	public String location;
	public String headers;
	public Map<String, String> agentCustomData;
	public String createTime;
	public String updatedTime;
	public String createdBy;
	public String updatedBy;
	public String trackingId;
	public ProviderAccount providerAccount;
	private AssetDetails assetDetails;

}
