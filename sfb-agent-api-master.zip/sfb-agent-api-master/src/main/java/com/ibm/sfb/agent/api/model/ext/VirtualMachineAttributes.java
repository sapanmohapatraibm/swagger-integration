
package com.ibm.sfb.agent.api.model.ext;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@JsonIgnoreProperties(ignoreUnknown=true)
public class VirtualMachineAttributes {
	
	private String networkName;
	private String providerTemplateId;
	private String instanceSize;
	private List<VMIpAddress> ipAddrs;
	private String status;
	
}
