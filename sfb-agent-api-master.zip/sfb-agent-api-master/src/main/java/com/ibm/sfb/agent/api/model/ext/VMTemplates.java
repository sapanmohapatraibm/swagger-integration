package com.ibm.sfb.agent.api.model.ext;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ibm.cm.api.model.CMAPIVMTemplate;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown=true)
public class VMTemplates extends Records {
	
	private List<CMAPIVMTemplate> items;
	
}
