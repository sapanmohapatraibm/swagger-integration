package com.ibm.sfb.agent.api.model.ext;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@JsonIgnoreProperties(ignoreUnknown=true)
public class VMIpAddress {

	private IPADDRESSTYPE type;
	private String ipAddress;
	
	public enum IPADDRESSTYPE {
		PRIVATE, PUBLIC;
	}
	
}
