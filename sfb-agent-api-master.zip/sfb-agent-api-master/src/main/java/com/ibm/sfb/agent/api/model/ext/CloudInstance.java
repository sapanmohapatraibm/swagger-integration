package com.ibm.sfb.agent.api.model.ext;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CloudInstance {
	
	private String cloudInstanceId;
	private String cloudInstanceName;
	private String locationCode;
	
	private CloudInstanceCredential credential;
	
}
