package com.ibm.sfb.agent.api.model.ext;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class SystemConnectivity {

    private Boolean specified;
    private String endpoint;
    private String username;
    private String password;
    private String apikey;

}
