package com.ibm.sfb.agent.api.model.ext;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProvisioningInfo {
	
	private String provisioningUrl;
	private String provisioningApiUserName;
	private String provisioningApiPassword;

}
