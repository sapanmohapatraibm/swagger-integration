package com.ibm.sfb.agent.api.enums;

public enum DelegationTypeEnum
{
    STATUS_POLL("Status Poll"), FIRE_AND_FORGET("Fire and Forget");
    
    private String delegationTypeName;

    private DelegationTypeEnum(String name)
    {
        this.delegationTypeName=name;
    }

    public String getDelegationTypeName()
    {
        return this.delegationTypeName;
    }
    
}
