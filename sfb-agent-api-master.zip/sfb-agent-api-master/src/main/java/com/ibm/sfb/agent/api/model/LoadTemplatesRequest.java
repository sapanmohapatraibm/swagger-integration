package com.ibm.sfb.agent.api.model;

import com.ibm.sfb.agent.api.model.ext.ProviderAccount;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoadTemplatesRequest {
	
	private String providerReference;
	private String provisioningReference;
	private ProviderAccount providerAccount;

}
