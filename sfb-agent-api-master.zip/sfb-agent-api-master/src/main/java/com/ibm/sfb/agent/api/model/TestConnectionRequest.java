package com.ibm.sfb.agent.api.model;

import com.ibm.sfb.agent.api.model.ext.TestConnectionProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestConnectionRequest {
	
	public TestConnectionProperties testConnectionProperties;

}
