package com.ibm.sfb.agent.api.model.ext;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestConnectionProperties {
	
	public String serviceDefinitionUUID;
	public String providerId;
	public String providerName;
	public String apiUrl;
	public String apiUserName;
	public String apiPassword;
	public String billingRef;
	public String provisioningRef;
	
}
