package com.ibm.sfb.agent.api.model;

import java.util.List;
import java.util.Map;

import com.ibm.sfb.agent.api.model.ext.OutputParam;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class StatusResponse {

	public String errorCode;
	public String errorDescription;
	public String trackingId;
	public String providerAssetId;
	public List<OutputParam> outputParams;
	public Map<String, String> accessInfo;
	public String status;
	public String comments;
	public String log;
	
}
