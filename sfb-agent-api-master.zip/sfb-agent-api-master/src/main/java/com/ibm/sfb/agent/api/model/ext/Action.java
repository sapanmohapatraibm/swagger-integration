package com.ibm.sfb.agent.api.model.ext;

import java.util.ArrayList;
import java.util.List;

import lombok.Builder;
import lombok.Getter;
import lombok.Singular;


@Builder
@Getter
public class Action {
	private String type;
	
	@Singular
	private List<InputParam> inputParams = new ArrayList<InputParam>();
	
	@Singular 
	private List<OutputParam> outputParams = new ArrayList<OutputParam>();
}
