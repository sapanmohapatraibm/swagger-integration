package com.ibm.sfb.agent.api.model.ext;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown=true)
public class ResourceGroup {

    private String imageTemplateId;
    private Network network;

}
