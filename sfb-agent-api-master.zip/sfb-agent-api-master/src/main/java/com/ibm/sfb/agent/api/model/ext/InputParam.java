package com.ibm.sfb.agent.api.model.ext;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class InputParam {

    private String name;
    private String type;
    private String toBeProvidedBy;
    private Boolean required;
	private String value;

}
