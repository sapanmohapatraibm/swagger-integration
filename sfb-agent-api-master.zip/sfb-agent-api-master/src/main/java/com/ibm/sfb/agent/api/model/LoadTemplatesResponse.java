package com.ibm.sfb.agent.api.model;

import java.util.List;

import com.ibm.sfb.agent.api.model.ext.VMTemplate;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class LoadTemplatesResponse {
	
	private List<VMTemplate> vmTemplates;

}