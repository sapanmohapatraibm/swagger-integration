package com.ibm.sfb.agent.api.model;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class CreateResponse {
	
	public String providerAssetId;
	public String trackingId;
	
}
