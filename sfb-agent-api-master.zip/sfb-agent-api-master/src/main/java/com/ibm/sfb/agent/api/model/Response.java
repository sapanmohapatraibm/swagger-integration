package com.ibm.sfb.agent.api.model;

import com.ibm.sfb.agent.api.model.ext.Status;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class Response {
	
	private int errorCode;
	private String errorDescription;
	private Status status;

}
