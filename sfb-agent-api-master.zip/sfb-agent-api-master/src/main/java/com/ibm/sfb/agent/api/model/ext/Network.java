package com.ibm.sfb.agent.api.model.ext;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown=true)
public class Network {
	
	private String name;
	private String providerIdentifier;
	
}
