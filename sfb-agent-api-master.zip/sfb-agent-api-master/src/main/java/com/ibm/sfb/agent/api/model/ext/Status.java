package com.ibm.sfb.agent.api.model.ext;

public enum Status {
	NEW, 
	COMPLETE, 
	IN_PROGRESS,
	FAILED;
}
