package com.ibm.sfb.agent.api.model;

import java.util.List;

import com.ibm.sfb.agent.api.model.ext.VirtualMachine;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class ListVMResponse extends Response {
	
	private List<VirtualMachine> vmAssets;
	
}