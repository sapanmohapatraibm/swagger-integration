package com.ibm.sfb.agent.api.model.ext;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class OutputParam {

    private String name;
    private String type;
    private String visibility;
    private String value;

}
