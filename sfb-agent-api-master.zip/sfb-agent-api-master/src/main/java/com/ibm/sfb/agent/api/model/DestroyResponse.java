package com.ibm.sfb.agent.api.model;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class DestroyResponse {

	public String trackingId;
	public String providerAssetId;

}
