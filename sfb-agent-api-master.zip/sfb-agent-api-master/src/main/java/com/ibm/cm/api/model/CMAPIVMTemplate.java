package com.ibm.cm.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown=true)
public class CMAPIVMTemplate {
	
	@JsonProperty(value="templateId")
	private String id;
	
	@JsonProperty(value="templateName")
	private String name;
	
}
