package com.ibm.sfb.agent.reference;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


import com.ibm.sfb.agent.api.BaseAgent;
import com.ibm.sfb.agent.api.enums.DelegationTypeEnum;
import com.ibm.sfb.agent.api.enums.SupportedVersions;
import com.ibm.sfb.agent.api.model.AgentInfo;
import com.ibm.sfb.agent.api.model.CreateRequest;
import com.ibm.sfb.agent.api.model.CreateResponse;
import com.ibm.sfb.agent.api.model.StatusRequest;
import com.ibm.sfb.agent.api.model.StatusResponse;
import com.ibm.sfb.agent.api.model.TestConnectionRequest;
import com.ibm.sfb.agent.api.model.ext.Action;
import com.ibm.sfb.agent.api.model.ext.SystemConnectivity;

import io.swagger.annotations.Api;

@RestController
@RequestMapping("/v1")
@Api(value="referenceagent", description="ReferenceAgent appliction service details")
public class ReferenceAgent extends BaseAgent {
	
	private static final Logger LOGGER = Logger.getLogger(ReferenceAgent.class);
	
	private Map<String, String> services = new Hashtable<>();

	@Override
	
	public AgentInfo info() {
		LOGGER.info("Entering info() .."); 
		
		SystemConnectivity systemConnectivity = SystemConnectivity.builder()
														.specified(true)
														.endpoint("http://localhost:9080/demo-agent/v1")
														.username("")
														.password("")
														.build();
		
		List<Action> actions = new ArrayList<Action>();
		actions.add(Action.builder().type("create").build());
		actions.add(Action.builder().type("status").build());
		actions.add(Action.builder().type("destroy").build());
		
		AgentInfo agentInfo = AgentInfo.builder()
								.name("Demo agent")
								.description("Demo agent to showcase SFB design")
								.systemConnectivity(systemConnectivity)
								.actions(actions)
								.delegationType(DelegationTypeEnum.STATUS_POLL.getDelegationTypeName())
								.supportedVersion(SupportedVersions.v2016_11_30.getVersion())
								.build();
		
		LOGGER.info("Leaving info().");
		return agentInfo;
	}
	
	@Override
	public CreateResponse create(CreateRequest req, MultipartFile[] submissions) throws Exception {
		LOGGER.info("Entering create() .."); 
		
		CreateResponse res = null;
		try {
			String serviceId = UUID.randomUUID().toString();
			services.put(serviceId, req.getAssetName());
			
			res = CreateResponse.builder()
					.trackingId(serviceId)
					.providerAssetId(serviceId)
					.build();
		} catch (Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
			throw ex;
		}
		
		LOGGER.info("Leaving create()."); 
		return res;
	}
	
	@Override
	public StatusResponse status(String jobId, StatusRequest request) throws Exception {
		LOGGER.info("Entering status() ..");
		
		LOGGER.info("Service name : " + request.getAssetName());
		LOGGER.info("Operation type : " + request.getOperationType());
		
		StatusResponse resp = StatusResponse.builder()
								.errorCode("0")
								.trackingId(jobId)
								.providerAssetId(jobId)
								.status("COMPLETE")
								.build();
		
		LOGGER.info("Leaving status().");
		return resp;
	}

//	@RequestMapping(value = "/destroy", method = RequestMethod.POST)
//	public DestroyResponse destroy(@RequestBody DestroyRequest request) throws Exception {
//		LOGGER.info("Entering destroy() ..");
//		
//		LOGGER.info("Service name : " + request.getAssetName());
//
//		String providerAssetId = request.getProviderAssetId();
//		DestroyResponse resp = DestroyResponse.builder()
//								.trackingId(providerAssetId)
//								.providerAssetId(providerAssetId)
//								.build();
//		
//		LOGGER.info("Leaving destroy().");
//		return resp;
//	}
	
	@Override
	public boolean testConnection(TestConnectionRequest request) throws Exception {
		LOGGER.info("Entering testConnection() ..");
		LOGGER.info("Leaving testConnection().");
		return true;
	}
	
}
